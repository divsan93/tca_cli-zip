workers   = 2
threads   = 500
timeout   = 300
accesslog = 'gunicorn.access.log'
errorlog  = 'gunicorn.debug.log'
capture_output = True
